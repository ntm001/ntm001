let data=[
  {
    Name: 'Person 1',
    Number: 273548,
    Address: 'Random Street 1, Random City, Random State',
    CNICNumber: 790020780605,
    PhoneNumber: '03221253910'
  },
  {
    Name: 'Person 2',
    Number: 1968,
    Address: 'Random Street 2, Random City, Random State',
    CNICNumber: 5100384375856,
    PhoneNumber: '032210013233'
  },
  {
    Name: 'Person 3',
    Number: 307996,
    Address: 'Random Street 3, Random City, Random State',
    CNICNumber: 4527720043214,
    PhoneNumber: '03228993481'
  },
  {
    Name: 'Person 4',
    Number: 923598,
    Address: 'Random Street 4, Random City, Random State',
    CNICNumber: 845844994575,
    PhoneNumber: '03229882955'
  },
  {
    Name: 'Person 5',
    Number: 306946,
    Address: 'Random Street 5, Random City, Random State',
    CNICNumber: 4972921399066,
    PhoneNumber: '03221631600'
  },
  {
    Name: 'Person 6',
    Number: 351530,
    Address: 'Random Street 6, Random City, Random State',
    CNICNumber: 8294981259665,
    PhoneNumber: '03224018086'
  },
  {
    Name: 'Person 7',
    Number: 629524,
    Address: 'Random Street 7, Random City, Random State',
    CNICNumber: 5247272747799,
    PhoneNumber: '03222174693'
  },
  {
    Name: 'Person 8',
    Number: 160990,
    Address: 'Random Street 8, Random City, Random State',
    CNICNumber: 4399756526233,
    PhoneNumber: '03227863118'
  },
  {
    Name: 'Person 9',
    Number: 857406,
    Address: 'Random Street 9, Random City, Random State',
    CNICNumber: 5291899385412,
    PhoneNumber: '03226302545'
  },
  {
    Name: 'Person 10',
    Number: 481500,
    Address: 'Random Street 10, Random City, Random State',
    CNICNumber: 4208108891170,
    PhoneNumber: '03225722247'
  },
  {
    Name: 'Person 11',
    Number: 529741,
    Address: 'Random Street 11, Random City, Random State',
    CNICNumber: 6164613229607,
    PhoneNumber: '03227274426'
  },
  {
    Name: 'Person 12',
    Number: 456814,
    Address: 'Random Street 12, Random City, Random State',
    CNICNumber: 1306527802440,
    PhoneNumber: '03221456334'
  },
  {
    Name: 'Person 13',
    Number: 829132,
    Address: 'Random Street 13, Random City, Random State',
    CNICNumber: 4706893747503,
    PhoneNumber: '03221562511'
  },
  {
    Name: 'Person 14',
    Number: 910789,
    Address: 'Random Street 14, Random City, Random State',
    CNICNumber: 3945865045769,
    PhoneNumber: '03229374728'
  },
  {
    Name: 'Person 15',
    Number: 710001,
    Address: 'Random Street 15, Random City, Random State',
    CNICNumber: 1697466712554,
    PhoneNumber: '03224909349'
  },
  {
    Name: 'Person 16',
    Number: 576588,
    Address: 'Random Street 16, Random City, Random State',
    CNICNumber: 9046175554869,
    PhoneNumber: '03225882136'
  },
  {
    Name: 'Person 17',
    Number: 357919,
    Address: 'Random Street 17, Random City, Random State',
    CNICNumber: 7479185574567,
    PhoneNumber: '03229468697'
  },
  {
    Name: 'Person 18',
    Number: 796993,
    Address: 'Random Street 18, Random City, Random State',
    CNICNumber: 2063906342334,
    PhoneNumber: '03222932563'
  },
  {
    Name: 'Person 19',
    Number: 507571,
    Address: 'Random Street 19, Random City, Random State',
    CNICNumber: 2866985769585,
    PhoneNumber: '03224224497'
  },
  {
    Name: 'Person 20',
    Number: 184511,
    Address: 'Random Street 20, Random City, Random State',
    CNICNumber: 4746326227646,
    PhoneNumber: '032210226096'
  },
  {
    Name: 'Person 21',
    Number: 205375,
    Address: 'Random Street 21, Random City, Random State',
    CNICNumber: 3764234450617,
    PhoneNumber: '03226770432'
  },
  {
    Name: 'Person 22',
    Number: 558411,
    Address: 'Random Street 22, Random City, Random State',
    CNICNumber: 2856730140365,
    PhoneNumber: '03225773749'
  },
  {
    Name: 'Person 23',
    Number: 585721,
    Address: 'Random Street 23, Random City, Random State',
    CNICNumber: 2162444408155,
    PhoneNumber: '03224332282'
  },
  {
    Name: 'Person 24',
    Number: 94204,
    Address: 'Random Street 24, Random City, Random State',
    CNICNumber: 1330251020227,
    PhoneNumber: '03225223257'
  },
  {
    Name: 'Person 25',
    Number: 72173,
    Address: 'Random Street 25, Random City, Random State',
    CNICNumber: 1418918791303,
    PhoneNumber: '032210099523'
  },
  {
    Name: 'Person 26',
    Number: 730984,
    Address: 'Random Street 26, Random City, Random State',
    CNICNumber: 1130295168783,
    PhoneNumber: '03226470054'
  },
  {
    Name: 'Person 27',
    Number: 832461,
    Address: 'Random Street 27, Random City, Random State',
    CNICNumber: 5229209497532,
    PhoneNumber: '03221870620'
  },
  {
    Name: 'Person 28',
    Number: 543636,
    Address: 'Random Street 28, Random City, Random State',
    CNICNumber: 1342547830370,
    PhoneNumber: '03225071877'
  },
  {
    Name: 'Person 29',
    Number: 560228,
    Address: 'Random Street 29, Random City, Random State',
    CNICNumber: 185257065606,
    PhoneNumber: '03221038251'
  },
  {
    Name: 'Person 30',
    Number: 540992,
    Address: 'Random Street 30, Random City, Random State',
    CNICNumber: 8709704077109,
    PhoneNumber: '032210607358'
  },
  {
    Name: 'Person 31',
    Number: 533935,
    Address: 'Random Street 31, Random City, Random State',
    CNICNumber: 9028952841057,
    PhoneNumber: '03224726560'
  },
  {
    Name: 'Person 32',
    Number: 475868,
    Address: 'Random Street 32, Random City, Random State',
    CNICNumber: 9792259764410,
    PhoneNumber: '03221309215'
  },
  {
    Name: 'Person 33',
    Number: 899884,
    Address: 'Random Street 33, Random City, Random State',
    CNICNumber: 3526299874961,
    PhoneNumber: '03224714331'
  },
  {
    Name: 'Person 34',
    Number: 242762,
    Address: 'Random Street 34, Random City, Random State',
    CNICNumber: 726302208574,
    PhoneNumber: '03224667523'
  },
  {
    Name: 'Person 35',
    Number: 856768,
    Address: 'Random Street 35, Random City, Random State',
    CNICNumber: 7046379087643,
    PhoneNumber: '03222695661'
  },
  {
    Name: 'Person 36',
    Number: 3227779,
    Address: 'Random Street 36, Random City, Random State',
    CNICNumber: 8835868775308,
    PhoneNumber: '03225132133'
  },
  {
    Name: 'Person 37',
    Number: 346989,
    Address: 'Random Street 37, Random City, Random State',
    CNICNumber: 8928080599643,
    PhoneNumber: '03221593093'
  },
  {
    Name: 'Person 38',
    Number: 683539,
    Address: 'Random Street 38, Random City, Random State',
    CNICNumber: 6061423099581,
    PhoneNumber: '03223250102'
  },
  {
    Name: 'Person 39',
    Number: 893687,
    Address: 'Random Street 39, Random City, Random State',
    CNICNumber: 3490343708707,
    PhoneNumber: '03222362651'
  },
  {
    Name: 'Person 40',
    Number: 150294,
    Address: 'Random Street 40, Random City, Random State',
    CNICNumber: 9395216648110,
    PhoneNumber: '03226656264'
  },
  {
    Name: 'Person 41',
    Number: 280680,
    Address: 'Random Street 41, Random City, Random State',
    CNICNumber: 8148915802787,
    PhoneNumber: '03224945567'
  },
  {
    Name: 'Person 42',
    Number: 659891,
    Address: 'Random Street 42, Random City, Random State',
    CNICNumber: 1641833670015,
    PhoneNumber: '032210808315'
  },
  {
    Name: 'Person 43',
    Number: 469782,
    Address: 'Random Street 43, Random City, Random State',
    CNICNumber: 1443558519834,
    PhoneNumber: '034410268119'
  },
  {
    Name: 'Person 44',
    Number: 808401,
    Address: 'Random Street 44, Random City, Random State',
    CNICNumber: 4672637377777,
    PhoneNumber: '03016285802'
  },
  {
    Name: 'Person 45',
    Number: 125945,
    Address: 'Random Street 45, Random City, Random State',
    CNICNumber: 2733809810906,
    PhoneNumber: '03255662216'
  },
  {
    Name: 'Person 46',
    Number: 832346,
    Address: 'Random Street 46, Random City, Random State',
    CNICNumber: 6287914527184,
    PhoneNumber: '03252038004'
  },
  {
    Name: 'Person 47',
    Number: 461353,
    Address: 'Random Street 47, Random City, Random State',
    CNICNumber: 605507358159,
    PhoneNumber: '03005932887'
  },
  {
    Name: 'Person 48',
    Number: 791803,
    Address: 'Random Street 48, Random City, Random State',
    CNICNumber: 5805721433636,
    PhoneNumber: '03112192716'
  },
  {
    Name: 'Person 49',
    Number: 698374,
    Address: 'Random Street 49, Random City, Random State',
    CNICNumber: 3920645453583,
    PhoneNumber: '032210010985'
  },
  {
    Name: 'Person 50',
    Number: 469687,
    Address: 'Random Street 50, Random City, Random State',
    CNICNumber: 3540477441501,
    PhoneNumber: '03219428123'
  }
]
export default data;