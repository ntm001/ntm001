import { Blog } from "@/types/blog";

const blogData: Blog[] = [
  {
    id: 1,
    title: "Best Telecom Companies in Pakistan...",
    paragraph:
      "Telecommunication is an important sector that has rapidly grow in the past few years in Pakistan.......",
    moreParagraph:"lorem1",
    image: "/images/blog/blog-01.jpg",
    author: {
      name: "Samuyl Joshi",
      image: "/images/blog/author-01.png",
      designation: "Graphic Designer",
    },
    tags:["creative"],
    publishDate: "coming soon.......",
  },
  {
    id: 2,
    title: "How To Check Mobile Number Detail in Pakistan.",
    paragraph:
      "Do you know SIM DETAIL is the first of its kind to provide you the accurate details about every.",
    moreParagraph:"lorem2",
    image: "/images/blog/blog-02.jpg",
    author: {
      name: "Musharof Chy",
      image: "/images/blog/author-02.png",
      designation: "Content Writer",
    },
    tags: ["computer"],
    publishDate: "coming soon.......",
  },
  {
    id: 3,
    title: "How can SIM DETAIL help you to be Safe from.",
    paragraph:
      "Scammers are available in the whole world. By whatever reasons or means, they always try to harm..",
    moreParagraph:"lorem3",
    image: "/images/blog/blog-03.jpg",
    author: {
      name: "Lethium Deo",
      image: "/images/blog/author-03.png",
      designation: "Content Writer",
    },
    tags: ["creative"],
    publishDate: "coming soon.......",
  },
  
];
export default blogData;
